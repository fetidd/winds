from dataclasses import dataclass
import os
from common.repo.abstract_repo import AbstractRepo, Item

@dataclass
class Connection(Item):
    client_id: str
    client_type: str

class ConnectionRepo(AbstractRepo[Connection]):
    TABLE_NAME = os.environ.get('CONNECTIONS_TABLE', '') # TODO what should happen if this is not set?
    ITEM_TYPE = Connection

    def get_connection(self, event) -> Connection:
        return super().get_item(event['requestContext']['connectionId'])
    
    def get_base_client(self) -> Connection:
        connections = super().scan()
        for connection in connections:
            if connection.client_type == "BASE":
                return connection
        raise Exception("No base client connected")