import logging
from uuid import uuid4

from common.utils import get_client, status
from common.models import SendWeightsPayload
from common.decorators import lambda_handler
from common.repo.dispatch_repo import DispatchRepo, Dispatch
from common.repo.connection_repo import ConnectionRepo
from common.api_client import ApiClient
from common.payloads.error_payload import ErrorPayload


logging.getLogger().setLevel('INFO')

@lambda_handler
def handler(payload: SendWeightsPayload, api_client, db_client):
    logging.info(f'send_weights: payload = {payload}')

    connection_repo = ConnectionRepo(db_client)
    this_connection = connection_repo.get_connection(payload.connection_id)
    api_client = ApiClient(api_client)

    # Get the connected base client, abort if none found
    try:
        base_client = connection_repo.get_base_client()
    except Exception as exc:
        logging.critical(f'send_weights: {exc}')
        api_client.error(this_connection, error_payload=ErrorPayload(f'{exc}, aborting...'))
        return status(400)

    # Create the new dispatch with provided weights
    dispatch_repo = DispatchRepo(db_client)
    create_new_dispatch(dispatch_repo, payload)

    # Ping the base client that new weight have been sent
    api_client.ping(base_client, message='New weights sent!')

    return status()


def create_new_dispatch(dispatch_repo: DispatchRepo, payload: SendWeightsPayload):
    dispatch = Dispatch(id=uuid4().hex)
    for line, weight in payload.weights.items():
        setattr(dispatch, f'line_{line}', weight)
    db_put_result = dispatch_repo.put_item(dispatch)
    logging.info(f'send_weights: db_put_result = {db_put_result}')
